# both-eyes-anime > Version 2. 2023-05-27 11-06pm
https://universe.roboflow.com/erentil/both-eyes-anime

Provided by a Roboflow user
License: CC BY 4.0

